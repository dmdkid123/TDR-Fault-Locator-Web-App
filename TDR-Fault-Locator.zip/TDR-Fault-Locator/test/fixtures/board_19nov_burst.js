// The 10:03 capture from David's board (35 sweeps averaged, ~30 ft cord in a connector that turned out not to be clamped),
// rebuilt as one 1000-sample sweep. Sample k here = k ns after the first burst pulse; the region 0..124 ns is copied exactly.
const head = [697,713,705,713,692,706,674,737,775,1089];                       // -10..-1 ns
const ns0_125 = ('1998 2074 1465 1016 999 980 760 728 741 756 784 755 741 938 1838 2598 2704 2715 2702 2686 1763 1064 1016 751 777 ' +
  '775 741 805 751 1223 2198 2488 2883 2929 2928 2869 2794 1873 1213 1016 733 765 782 763 876 1114 2509 3535 3591 3565 ' +
  '3574 3581 3518 3057 1728 1028 1034 1052 1490 2235 3080 3445 3374 3392 3442 3436 3312 3300 3329 3391 3393 3355 3376 3382 3366 ' +
  '3357 3325 3320 3262 3268 3263 3261 3249 3283 3293 3264 3256 3254 3253 3245 3212 3227 3207 3210 3193 3193 3186 3179 3170 3161 ' +
  '3148 3146 3144 3164 3144 3146 3161 3141 3120 3108 3108 3108 3096 3098 3077 3086 3082 3083 3078 3065 3064 3044 3062 3046 3052').split(' ').map(Number);
const every5 = ('3051 3038 3002 3000 3011 2986 3002 3014 2997 3017 2995 2999 2995 3005 3031 2952 2957 2976 2921 2913 2902 2894 2876 2822 2803 2790 2766 2734 2717 2673 2648 2664 2607 2598 2611 2609 2607 2593 2583 2571 2609 2596 2629 2609 2628 2601 2639 2568 2591 2627 2590 2591 2558 2550 2518 ' +
  '2500 2499 2492 2428 2426 2414 2378 2382 2343 2357 2325 2329 2290 2322 2303 2286 2315 2286 2331 2308 2302 2318 2312 2339').split(' ').map(Number);   // 125..519 ns, every 5
function sweep(start) {                       // start = where ns 0 lands in the 1000-sample window
  const w = new Array(1000).fill(0), put = (ns, v) => { w[((start + ns) % 1000 + 1000) % 1000] = v; };
  for (let ns = 559; ns < 990; ns++) put(ns, Math.round(700 - 520 * Math.exp(-(ns - 559) / 120)));   // low half after the fall, sagging up to ~700
  head.forEach((v, k) => put(k - 10, v));
  ns0_125.forEach((v, k) => put(k, v));
  for (let ns = 125; ns < 520; ns++) { const f = (ns - 125) / 5, a = every5[Math.floor(f)], b = every5[Math.min(every5.length - 1, Math.floor(f) + 1)]; put(ns, Math.round(a + (b - a) * (f - Math.floor(f)))); }
  for (let ns = 520; ns < 559; ns++) put(ns, 2330);
  return w;
}
module.exports = { sweep, REAL_LAUNCH_NS: 59 };
