# TDR Fault Locator (ECE 480 Team 10)

Web app plus ESP32 firmware for a time-domain reflectometer that finds wiring faults in 120 Ω automotive harnesses.
David DelSanto owns the web app; Tyler owns the firmware. Sponsor: Dale Koch (DLK3 Consulting).

**Read `docs/HANDOFF.md` first.** It is the history of the project so far: the hardware, the board protocol, every
feature, what was tried on the real board, and the open hardware problems.

## Layout

- `index.html`, `css/`, `js/`: the web app. Plain classic scripts, no build step, no npm packages. It must keep working
  when opened from `file://` and on GitHub Pages (https://dmdkid123.github.io/TDR-Fault-Locator-Web-App/).
  - `js/tdr.js` analysis engine (also runs in Node), `js/device.js` USB serial + packet parser + sweep alignment,
    `js/app.js` UI, `js/chart.js` scope chart, `js/viewer.js` WebGL2 3D view, `js/demo.js` demo tab,
    `js/harness_data.js` mock harness geometry.
- `test/`: Node tests. `test/fixtures/board_19nov_burst.js` is a real capture from the board; keep that test passing.
- `firmware/`: PlatformIO project (Arduino-ESP32). `firmware/host_test/run.sh` checks it on a PC and decodes its
  packets with `js/device.js`.

## Commands

- Run the app: Live Server on `index.html`, or `python -m http.server 5500` (Windows: `py -m http.server 5500`).
- App tests: `node test/tdr.test.js && node test/device.test.js` (both must print `ALL PASSED`).
- Firmware check (Linux/macOS/WSL with g++, Python 3, Node): `sh firmware/host_test/run.sh`.

## Rules

- `index.html` has `<meta name="tdr-build" content="N">` and the script tags use `?v=N`; `js/app.js` has
  `const BUILD = 'N'`. When you change `index.html` or `js/app.js`, bump N in all three places together. A mismatch
  shows a red bar on the page.
- Board protocol (matches `firmware/src`): 921600 baud, app sends `S` to start and `I` to stop; packets
  `55 AA | count u16 | sweepID u32 | count x u16 | CRC16-MODBUS`, little-endian; text lines `POST_PASSED`, `INFO`,
  `WARN: NO_SWEEP_SYNC`, `WARN: SAMPLER_OVERRUN idx=<n> missed=<k>` (printed before that sweep's packet), `ERR: ...`.
  Change both sides together and rerun `firmware/host_test/run.sh`.
- Timing: 1000 samples per sweep, 100 µs apart, 100,000x stretch, so 1 ns per sample. One sweep is exactly one 1 MHz
  period, so sweeps are circular. Distance d = vp * c * t / 2, default vp 0.66.
- Launch edge: the rising edge that starts the longest high stretch (`sweepLaunch` in `js/device.js`). The board puts a
  burst of ~6 ns pulses before the real launch; earlier rules locked onto them. The device passes the launch index to
  the engine (`cfg.launchIdx`). Do not go back to "biggest edge" or "end of the longest low stretch".
- Do not change firmware files without saying so clearly; Tyler owns them.
- Check changes against real board data where possible, not only simulated captures.
