# TDR Fault Locator: handoff summary (19 Nov 2026, updated 11:00)

ECE 480 Team 10, sponsor Dale Koch (DLK3 Consulting). David DelSanto owns the web app (user interface). Tyler owns the ESP32 firmware.

## What to give a new conversation

1. This file.
2. `TDR-Fault-Locator.zip`: the whole project in one folder (web app plus firmware). Latest app version is **build 13** (build 11 = launch-edge fix; build 12 = "no echo" check; build 13 = ETHERNET cable preset). David works in `Downloads\TDR-Fault-Locator\TDR-Fault-Locator` (nested one level), tests on a local server, then pushes to GitHub. He prefers this chat to do the coding, not Claude in VS Code. (Checked 19 Nov 10:40 on build 10: `index.html` and `app.js` both said build 10; `test/tdr.test.js`, `test/device.test.js` and `firmware/host_test/run.sh` all pass, including the new `fillSlots` check and compiles for Arduino-ESP32 2.x and 3.x.)
3. Live site: https://dmdkid123.github.io/TDR-Fault-Locator-Web-App/ (GitHub repo `dmdkid123/TDR-Fault-Locator-Web-App`). The site may be behind the zip until the latest files are pushed.

## The system

- Pulse generator matched to 120 Ω, equivalent-time sampling. Si5351: CLK0 = 1,000,000 Hz (pulse), CLK1 = 999,990 Hz (strobe), 10 Hz beat, 100,000× time stretch.
- ESP32 samples the sampler's WAVE output on GPIO34 (ADC 11 dB, 12-bit) every 100 µs, 1000 samples per sweep, so **1 ns per sample** (about 9.9 cm at vp 0.66). One sweep is exactly one 1 MHz period, so sweeps are circular.
- GPIO27 = sweep sync (falling edge starts a sweep). The firmware disables the interrupt after the first edge to ignore bounce.
- Distance: d = vp · c · t / 2. Default vp 0.66, Z0 120 Ω.
- POC board BNCs: **J4 = Sync**, **J3 = Waveform (WAVE)**.

## Firmware ↔ app protocol (verified, host tests pass)

- 921600 baud. App sends `S` to start sweeping, `I` to stop.
- Packet, little-endian: `55 AA` | count u16 | sweepID u32 | count × u16 | CRC16 (MODBUS, over samples only).
- Text lines: `POST_PASSED: SYSTEM_READY`, `INFO: ADC_US=…`, `WARN: NO_SWEEP_SYNC`, `ERR: SI5351_I2C_FAILED`, and `WARN: SAMPLER_OVERRUN idx=<n> missed=<k>`, printed **before** the damaged sweep's packet. Late slots are filled by interpolation, not shifted.

## Web app (plain HTML/JS, no build step)

- Run: open the folder in VS Code, then Live Server on `index.html` (or the task "Start web app"). Chrome or Edge only for USB.
- Files: `js/tdr.js` (analysis engine), `js/device.js` (serial, packet parser, sweep alignment), `js/app.js` (UI), `js/chart.js`, `js/viewer.js` (WebGL 3D), `js/demo.js`, `js/harness_data.js` (mock harness). Tests: `node test/tdr.test.js`, `node test/device.test.js`. Firmware check: `sh firmware/host_test/run.sh`.
- `index.html` has `<meta name="tdr-build">`, and it must match `BUILD` in `js/app.js`. Otherwise a red bar appears. Always ship those two together.

### Features in place

- Binary packet decode; sweep alignment on the launch edge (A1), keep sweeps with `missed <= 2` (A2), per-capture summary in the Board log (A3).
- Launch-edge finder (build 11): the launch is the rising edge that **starts the longest high stretch** (smoothed, 25–33% hysteresis), with a raw-sample check that splits off a pulse running into the launch with a few ns gap, then a snap to the steepest rise. The device passes the launch index (sample 80 after rotation) with each capture, and the engine uses it (`cfg.launchIdx`) and takes the baseline as the 20th percentile of the lead-in. Before build 11 it used "end of the longest low stretch" and locked onto the first pre-launch pulse; that caused the fake short at about 0.6 m and the echo pattern on 19 Nov. Regression test: `test/fixtures/board_19nov_burst.js` (the real 10:03 capture), in `test/device.test.js`.
- Sub-sample edge timing, live view, history/compare, print report, calibration wizard with saved wire types, branch identification from missing end echoes, junction handling, virtual device, demo tab.
- **BENCH_CABLE** circuit: enter the length in ft, or leave it blank to *measure* it (first full open = the end). It flags "Length uncertain" when the trace doesn't look like a clean cable.
- Reflections past the far end are shown as "Echo past the end", not faults.
- **Ignore closer than (m)**: hides the connector's reflection near the board.
- **ETHERNET** circuit (build 13), alongside BENCH_CABLE: one twisted pair, length typed in ft or blank to measure. Picking it switches to Z0 100 Ω and vp 0.68 (typical Cat5e/Cat6, 0.64–0.70 by brand); picking another circuit restores the previous values, and edits made while on ETHERNET are kept for it (`CABLES` and `applyCablePreset` in `js/app.js`). Reach is about 50 m, so the 100 m Ethernet maximum is out of range.
- **No echo check** (build 12, widened in build 13 to the whole capture, about 48–50 m, so a long cable's end is not mistaken for nothing): if nothing reflects the verdict is "Nothing reflected back": either nothing is connected, or the line ends in a matched load (a 100 Ω resistor on a 100 Ω line absorbs the pulse, so it is invisible to a TDR).
- Setup defaults: proto binary, baud 921600, avg 4, sample interval **100 µs** (it was wrongly 110 on David's browser at one point; this must be 100).
- 19 Nov bench run: Board log showed **0 overruns**, so the firmware overrun fixes work.

## Open hardware problems (as of 19 Nov, 10:25)

1. **Burst of pulses / cable not seen.** With any cable attached (5.1 ft and ~30 ft gave nearly the same pattern) the trace shows short pulses about 6 ns wide about every 16 ns for the first ~60 ns, then stays high. A hard drop appears at about 0.6 m every time. The 30 ft cable's end (expected about 92 ns / 9.1 m, about 9.2 ms on the scope) is not visible. It showed a clean open last week, before the connector change.
   - **Update 10:25:** with **nothing** in the lever connector, the scope WAVE trace (J3, triggered on J4 sync falling, 1 ms/div, delay −800 µs) looks **the same** as with the 30 ft cord: the launch goes straight to about 2.3 V on WAVE (≈ 3.1 V at the test point, i.e. an open) and slowly creeps to about 2.5 V. So the board never saw the cord. The sampler reads an open correctly; the break is between the cord and the cable point.
   - Likely causes: the Phoenix lever plug's **levers were up** (released) in the photo, so the wires weren't clamped; the plug may not be fully seated on the MSTBA header; the header was just soldered onto the POC, so its joints may be bad.
   - Next steps: clamp the levers down, seat the plug, meter plug cable pin → cable-point test point / Rs (~0 Ω) and plug ground pin → GND (~0 Ω), reflow if open. Then check levels in the connector: **short ≈ 0.15 V WAVE, 100 Ω resistor ≈ 1.2 V WAVE, open ≈ 2.3–2.46 V**. Once the short and resistor read right, retest the 30 ft cord (same twisted pair, e.g. orange/orange-white) at 2 ms/div: about 1.2 V for about 9.2 ms, then the step up.
   - The pulses before the real launch are still there whatever is connected, so they come from the board side (possibly CLK1 coupling across the breadboard jumpers). They sit before the measurement window. **Done in build 11:** the app now skips them. On the 10:03 capture it finds the launch at 60 ns (real ≈ 59) and reports no reflections, which matches the scope finding that the cord was not connected.
2. **ADC headroom.** Right after the launch the level is about 3,750/4,095 counts (about 3.0 V), above the ESP32's accurate 11 dB range (about 2.45 V), and the low part touches 0. An open (about 2× the step) can be clipped. Suggested fix: a divider (plus a small offset) between WAVE and GPIO34 so the step tops out around 1.0–1.2 V. (Note: Ari doesn't want hardware changes; a software alternative is to calibrate Vref ≈ 3.1 V and treat readings above ~2.45 V as approximate.)
3. **Sag.** Both halves of the sweep drift toward the middle (looks AC-coupled, roughly a 40 ms time constant in real time). The app copes, but far steps shrink.
4. Earlier, `WARN: NO_SWEEP_SYNC` appeared for a while (GPIO27 sync missing). It was fixed by rewiring; check the sync wiring if it comes back.

## Scope settings that worked (Agilent DSO9064A)

- CH1 = J4 sync, CH2 = J3 WAVE, both 1 MΩ, DC, 1:1 (coax). CH2 500 mV/div, offset ~1.3 V.
- Trigger: CH1, edge falling, 1.65 V, Normal, holdoff ~50 ms. Horizontal reference Left, delay **−800 µs** (negative, so the launch sits 0.8 div from the left). 1 ms/div for short cables, 2 ms/div for 30 ft.
- Conversions: 1 ms on the scope = 10 ns equivalent ≈ 0.99 m at vp 0.66. App volts at the test point = (WAVE − 0.15) / 0.7.

## Still waiting on

- The real CAD harness export format from Dale (the app uses mock geometry).
- Which vehicle the harness data is for (the schematics look Tesla-like vs "Pacifica").
- A known-length cable test to calibrate vp once the cable connection is fixed.

## Also in outputs from earlier

- `tdr_locator.py` + `test_tdr.py`: the original Python TDR engine with a CLI (`demo`, `analyze`). David's copy is `tdr_locatorV2.py`. The web app's engine matched it on 5 sample CSVs, but the web app has since added sub-sample timing.
